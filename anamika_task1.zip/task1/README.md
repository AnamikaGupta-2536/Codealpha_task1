# Task 1 - CGPA Calculator

This is the first task from my internship at CodeAlpha.

### Features:
- Takes number of courses as input
- Inputs grades and credit hours for each course
- Calculates total grade points and CGPA
- Displays each course grade and the final CGPA

### Language:
C++

Submitted by: Anamika Gupta
